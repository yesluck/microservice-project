module.exports = {
  googleClientID: "362228718688-l4t8ujt9hthq7tc0e83h90bt8og1l9bd.apps.googleusercontent.com",
  googleClientSecret: "peRkEP6FAC5395y_m71SUois"
}
