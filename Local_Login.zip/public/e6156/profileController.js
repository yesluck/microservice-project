//var app = angular.module("CustomerApp", []);

CustomerApp.controller("ProfileController", function($scope, $http, $location, $window) {

    console.log("Profile controller loaded.")


});

